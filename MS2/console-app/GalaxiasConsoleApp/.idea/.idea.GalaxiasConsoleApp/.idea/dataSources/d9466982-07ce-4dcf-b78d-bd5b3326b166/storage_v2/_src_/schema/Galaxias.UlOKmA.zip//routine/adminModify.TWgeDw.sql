create
    definer = root@localhost procedure adminModify(IN pPilotID int, IN pPilotName varchar(30),
                                                   IN pPilotPassword varchar(20), IN pEmail varchar(50),
                                                   IN pLoginAttempts int, IN pPilotLocked tinyint(1),
                                                   IN pAdministrator tinyint(1), IN pTotalScore int)
begin
    declare modifyPilot int default null;

    if exists(
            select *
            from tblPilot
            where PilotName = pPilotName
              and PilotID <> pPilotID
        ) then
        select 'failed - pilot name exists' as message;

    else
        set
            modifyPilot = (select PilotID
                           from tblPilot
                           where PilotID = pPilotID);
    end if;
    if modifyPilot is null then
        select 'failed - bad pilot id' as message;

    else
        update
            tblPilot
        set PilotName     = pPilotName,
            PilotPassword = pPilotPassword,
            Email         = pEmail,
            LoginAttempts = pLoginAttempts,
            PilotLocked   = pPilotLocked,
            Administrator = pAdministrator,
            TotalScore    = pTotalScore
        where PilotID = pPilotID;

        select 'success - pilot modified' as message;

    end if;

end;

