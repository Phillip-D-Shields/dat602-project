create
    definer = root@localhost procedure newGalaxy(IN pPilotID int, IN pGalaxyName varchar(50))
begin

    declare maxPilots int default 6;

    declare activePilots int default 1;

    declare galaxyStatus int default 1;

    declare pilotNumber int default 1;

    declare score int default 0;

    declare newGalaxyID int default null;

    declare newMapID int default null;

    declare homeVectorID int default null;

    declare endVectorID int default null;

    declare rowMin int default 1;

    declare rowMax int default 20;

    declare colMin int default 1;

    declare colMax int default 20;

    declare elementCount int default 0;

    declare elementVector int default null;

    declare elementType int default 1;

    declare newSessionID int default null;

    if exists(
            select GalaxyName
            from tblGalaxy
            where GalaxyName = pGalaxyName
        ) then
        select 'bad galaxy name' as message;

    else
        insert into tblGalaxy(GalaxyName, maxPilots, ActivePilots, GalaxyStatus)
        values (pGalaxyName, maxPilots, ActivePilots, GalaxyStatus);

        set
            newGalaxyID = last_insert_id();

-- map
        insert into tblMap(GalaxyID, xMax, yMax)
        values (newGalaxyID, rowMax, colMax);

        set
            newMapID = last_insert_id();

-- map vectors
        vectorRow:
        loop
            vectorCol:
            loop
                insert into tblVector(MapID, xPosition, yPosition, VectorActive)
                values (newMapID, rowMin, colMin, true);

                set
                    colMin = colMin + 1;

                if colMin > 10 then
                    set
                        colMin = 1;

                    leave vectorCol;

                end if;

            end loop vectorCol;

            set
                rowMin = rowMin + 1;

            if rowMin > 10 then
                leave vectorRow;

            end if;

        end loop vectorRow;

-- finds new home VectorID
        select VectorID
        into homeVectorID
        from tblVector
        where xPosition = 1
          and yPosition = 1
          and MapID = newMapID;

-- finds new end VectorID
        select VectorID
        into endVectorID
        from tblVector
        where xPosition = 10
          and yPosition = 10
          and MapID = newMapID;

-- creates all elements on random vectors
        getElement:
        loop
            addElement:
            loop
                set
                    elementVector = (select floor(rand() * (endVectorID - homeVectorID) + homeVectorID));

                if not exists(
                        select *
                        from tblVectorElement
                        where VectorID = elementVector
                    ) then
                    set
                        elementCount = elementCount + 1;

                    insert into tblVectorElement(VectorID, ElementID)
                    values (elementVector, elementType);

                end if;

                if elementCount = 25 then
                    set
                        elementCount = 0;

                    leave addElement;

                end if;

            end loop addElement;

            set
                elementType = elementType + 1;

            if elementType > 6 then
                set
                    elementType = 1;

                leave getElement;

            end if;

        end loop getElement;


        insert into tblSession(PilotID,
                               GalaxyID,
                               MapID,
                               VectorID,
                               PilotNumber,
                               Score,
                               SessionActive)
        values (pPilotID,
                newGalaxyID,
                newMapID,
                homeVectorID,
                PilotNumber,
                score,
                true);

        set
            newSessionID = last_insert_id();


        while elementType <= 4
            do
                insert into tblInventory(ElementID, PilotID, SessionID, Quantity)
                values (elementType, pPilotID, newSessionID, 0);

                set
                    elementType = elementType + 1;

            end while;

        select 'new galaxy initiated' as message;

    end if;

end;

