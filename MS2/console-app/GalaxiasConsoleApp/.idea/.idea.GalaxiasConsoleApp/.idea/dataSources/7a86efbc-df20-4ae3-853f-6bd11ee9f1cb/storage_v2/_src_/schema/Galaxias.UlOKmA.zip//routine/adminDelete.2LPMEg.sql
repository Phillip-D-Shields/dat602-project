create
    definer = root@localhost procedure adminDelete(IN pPilotID int)
begin
    declare deletePilot int default null;

    select PilotID
    into deletePilot
    from tblPilot
    where PilotID = pPilotID;

    if deletePilot is null then
        select 'failed - bad pilot id' as message;

    else
        delete
        from tblPilot
        where PilotID = pPilotID;

        select 'success - pilot deleted' as message;

    end if;

end;

