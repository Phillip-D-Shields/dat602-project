create
    definer = root@localhost procedure pilotDelete(IN pPilotName varchar(30), IN pPilotPassword varchar(20))
begin
    declare verifyPilot int default null;

    select PilotID
    from tblPilot
    where PilotName = pPilotName
      and PilotPassword = pPilotPassword
    into verifyPilot;

    if verifyPilot is null then
        select 'bad name or password' as message;

    else
        delete
        from tblPilot
        where PilotName = pPilotName;

        select 'success - pilot deleted' as message;

    end if;

end;

