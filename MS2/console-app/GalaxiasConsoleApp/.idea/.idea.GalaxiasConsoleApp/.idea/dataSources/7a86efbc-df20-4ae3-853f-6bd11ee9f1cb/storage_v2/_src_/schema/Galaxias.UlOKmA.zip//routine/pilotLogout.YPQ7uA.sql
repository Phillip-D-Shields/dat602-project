create
    definer = root@localhost procedure pilotLogout(IN pPilotID int)
begin
    update
        tblPilot
    set PilotOnline = false
    where PilotID = pPilotID;

    select 'success - pilot offline' as message;

end;

