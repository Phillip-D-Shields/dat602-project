create
    definer = root@localhost procedure dmlGalaxiasDB()
begin
    insert into tblElement (ElementName, ElementDescription, ElementValue)
    values ('gold', 'shiny shiny', '10'),
           ('ether', 'mysterious power', '50'),
           ('float gem', 'floaty floaty', '100'),
           ('vibranium', 'all powerful', '500'),
           ('void energy', 'voidy voidy', '-500'),
           ('black hole', 'massive damage', '-500');


    call pilotRegistration('phill', '1234', 'phill@email.com');

    call pilotRegistration('stu', '1234', 'stu@email.com');

    call pilotRegistration('jeebus', '1234', 'jeebus@email.com');

    call pilotRegistration('alex', '1234', 'alex@email.com');

    call pilotRegistration('tina', '1234', 'tina@email.com');

    call pilotRegistration('cpt nope', '1234', 'nope@email.com');

    call pilotRegistration('god', '1234', 'god@email.com');


-- test data modify pilot
    call adminModify(
            '1',
            'phill',
            '1234',
            'phill@email.com',
            '0',
            false,
            true,
            '10000'
        );

    call adminModify(
            '3',
            'jeebus',
            '1234',
            'jeebus@email.com',
            '0',
            false,
            false,
            '1500'
        );

    call adminModify(
            '2',
            'stu',
            '1234',
            'stu@email.com',
            '0',
            false,
            false,
            '7500'
        );

    call adminModify(
            '4',
            'alex',
            '1234',
            'alex@email.com',
            '0',
            false,
            false,
            '50000'
        );

    call adminModify(
            '7',
            'god',
            '1234',
            'god@email.com',
            '0',
            true,
            true,
            '500000'
        );

-- test data new galaxy
    call newGalaxy('4', '000004');

    call newGalaxy('3', '000003');

    call newGalaxy('2', '000002');

-- test data join galaxy
    call joinGalaxy('1', '1');

    call joinGalaxy('3', '1');

    call joinGalaxy('7', '2');

    call joinGalaxy('5', '1');

-- inventory data add for console app demo
    update
        tblInventory
    set Quantity = 10
    where PilotID = 3
      and SessionID = 2
      and ElementID = 1;

    update
        tblInventory
    set Quantity = 1
    where PilotID = 3
      and SessionID = 2
      and ElementID = 2;

    update
        tblInventory
    set Quantity = 2
    where PilotID = 3
      and SessionID = 2
      and ElementID = 3;

    update
        tblInventory
    set Quantity = 1
    where PilotID = 3
      and SessionID = 2
      and ElementID = 4;

end;

