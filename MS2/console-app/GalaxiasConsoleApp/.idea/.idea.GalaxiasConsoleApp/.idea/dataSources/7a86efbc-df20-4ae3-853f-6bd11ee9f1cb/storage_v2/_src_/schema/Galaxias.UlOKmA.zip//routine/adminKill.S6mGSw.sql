create
    definer = root@localhost procedure adminKill(IN pGalaxyID int)
begin
    if exists(
            select GalaxyID
            from tblGalaxy
            where GalaxyID = pGalaxyID
        ) then
        delete
        from tblGalaxy
        where GalaxyID = pGalaxyID;

        select 'galaxy destroyed' as message;

    else
        select 'unacceptable galaxy' as message;

    end if;

end;

