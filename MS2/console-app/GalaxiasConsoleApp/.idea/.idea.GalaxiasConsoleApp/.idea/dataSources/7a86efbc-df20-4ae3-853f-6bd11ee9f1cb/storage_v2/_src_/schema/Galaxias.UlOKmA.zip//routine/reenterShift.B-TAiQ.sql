create
    definer = root@localhost procedure reenterShift(IN pSessionID int, IN pPilotID int, IN pGalaxyID int,
                                                    IN pxPosition int, IN pyPosition int)
begin

    declare currentMapID int default null;

    declare homeVectorID int default null;

    declare startVectorID int default null;

    declare targetVectorID int default null;

    declare currentCount int default null;

    declare nextPilot int default null;

    set
        currentMapID = (select MapID
                        from tblSession
                        where SessionID = pSessionID
                          and PilotID = pPilotID);

    set
        homeVectorID = (select VectorID
                        from tblVector
                        where MapID = currentMapID
                          and xPosition = 1
                          and yPosition = 1);

    set
        startVectorID = (select VectorID
                         from tblSession
                         where SessionID = pSessionID
                           and PilotID = pPilotID);

    if exists(
            select *
            from tblVector as tv
            where (
                        tv.xPosition = pxPosition
                    and tv.yPosition = pyPosition
                )
              and tv.VectorID in (select tv2.VectorID
                                  from tblSession as s
                                           join tblVector as t on s.VectorID = t.VectorID
                                           join tblVector as tv2 on t.VectorID <> tv2.VectorID
                                  where t.MapID = currentMapID
                                    and (
                                          (tv2.xPosition = t.xPosition + 1)
                                          or (tv2.xPosition = t.xPosition - 1)
                                          or (tv2.xPosition = t.xPosition)
                                      )
                                    and (
                                          (tv2.yPosition = t.yPosition + 1)
                                          or (tv2.yPosition = t.yPosition - 1)
                                          or (tv2.yPosition = t.yPosition)
                                      )
                                    and s.SessionID = pSessionID
                                    and s.PilotID = pPilotID)
        ) then
        set
            targetVectorID = (select VectorID
                              from tblVector
                              where xPosition = pxPosition
                                and yPosition = pyPosition
                                and MapID = currentMapID);

-- check to see if vector is available
        if exists(
                select VectorID
                from tblVector
                where VectorID = targetVectorID
                  and VectorActive = true
            ) then
            update
                tblSession
            set VectorID = targetVectorID
            where SessionID = pSessionID;

-- sets new vector if <> starting vector
            update
                tblVector
            set VectorActive = false
            where VectorID = targetVectorID
              and VectorID <> homeVectorID;

-- score points
            if exists(
                    select VectorID
                    from tblVectorElement
                    where VectorID = targetVectorID
                ) then
                update
                    tblInventory
                set Quantity = Quantity + 1
                where ElementID = (select ElementID
                                   from tblVectorElement
                                   where VectorID = targetVectorID);


                update
                    tblSession
                set Score = Score + (select a.ElementValue
                                     from tblElement as a
                                              join tblVectorElement as t on a.ElementID = t.ElementID
                                     where t.VectorID = targetVectorID)
                where SessionID = pSessionID;

-- removes element
                delete
                from tblVectorElement
                where VectorID = targetVectorID;

            end if;


            set
                currentCount = (select count(*)
                                from tblSession
                                where GalaxyID = pGalaxyID);

            set
                nextPilot = (select PilotNumber
                             from tblSession
                             where SessionID = pSessionID);


            findNextPilot:
            loop
                if nextPilot < CurrentCount then
                    set
                        nextPilot = nextPilot + 1;

                else
                    set
                        nextPilot = 1;

                end if;


                if exists(
                        select PilotNumber
                        from tblSession
                        where GalaxyID = pGalaxyID
                          and PilotNumber = nextPilot
                          and SessionActive = true
                    ) then
                    update
                        tblGalaxy
                    set ActivePilots = nextPilot
                    where GalaxyID = pGalaxyID;

                    leave findNextPilot;

                end if;

            end loop findNextPilot;

            select 'acceptable shift' as message;

        else
            select 'vector inaccessible' as message;

        end if;

    else
        select 'unacceptable shift' as message;

    end if;


    call checkGalaxy(
            pPilotID,
            pGalaxyID,
            (select MapID
             from tblSession
             where PilotID = pPilotID
               and GalaxyID = pGalaxyID)
        );

end;

