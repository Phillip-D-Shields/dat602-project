create
    definer = root@localhost procedure joinGalaxy(IN pPilotID int, IN pGalaxyID int)
begin

    declare currentCount int default null;

    declare maxCount int default null;

    declare pilotNumber int default null;

    declare sessionMapID int default null;

    declare homeVectorID int default null;

    declare score int default 0;

    declare newSessionID int default null;

    declare elementType int default 1;

    declare existingSessionID int default null;

    declare existingVectorID int default null;

    declare onlineCount int default null;

    set
        sessionMapID = (select MapID
                        from tblMap
                        where GalaxyID = pGalaxyID);

    set
        homeVectorID = (select VectorID
                        from tblVector
                        where xPosition = 1
                          and yPosition = 1
                          and MapID = sessionMapID);

    set
        onlineCount = (select count(*)
                       from tblSession
                       where GalaxyID = pGalaxyID
                         and SessionActive = true);

-- new or returning pilot
    if exists(
            select SessionID
            from tblSession
            where PilotID = pPilotID
              and GalaxyID = pGalaxyID
        ) then
        set
            existingSessionID = (select SessionID
                                 from tblSession
                                 where PilotID = pPilotID
                                   and GalaxyID = pGalaxyID);

        set
            existingVectorID = (select VectorID
                                from tblSession
                                where PilotID = pPilotID
                                  and GalaxyID = pGalaxyID);


        update
            tblSession
        set SessionActive = true
        where SessionID = existingSessionID;

-- check last vector
        if exists(
                select VectorID
                from tblVector
                where VectorID = existingVectorID
                  and VectorActive = true
            ) then
            update
                tblVector
            set VectorActive = false
            where VectorID = existingVectorID
              and VectorID <> homeVectorID;


            if onlineCount = 0 then
                update
                    tblGalaxy
                set ActivePilots = (select PilotNumber
                                    from tblSession
                                    where PilotID = pPilotID
                                      and GalaxyID = pGalaxyID)
                where GalaxyID = pGalaxyID;

            end if;

            select 'you live again' as message;

        else -- link to reenterShift procedure with user input
            select 'inaccessible - choose another vector' as message;

        end if;

    else
        set
            currentCount = (select count(*)
                            from tblSession
                            where GalaxyID = pGalaxyID);

        set
            maxCount = (select maxPilots
                        from tblGalaxy
                        where GalaxyID = pGalaxyID);

        if currentCount < maxCount then
            set
                PilotNumber = (select count(*)
                               from tblSession
                               where GalaxyID = pGalaxyID) + 1;

-- new session
            insert into tblSession(PilotID,
                                   GalaxyID,
                                   MapID,
                                   VectorID,
                                   PilotNumber,
                                   Score,
                                   SessionActive)
            values (pPilotID,
                    pGalaxyID,
                    sessionMapID,
                    homeVectorID,
                    PilotNumber,
                    score,
                    true);

            set
                newSessionID = last_insert_id();

-- pilot inventory
            while elementType <= 4
                do
                    insert into tblInventory(ElementID, PilotID, SessionID, Quantity)
                    values (elementType, pPilotID, newSessionID, 0);

                    set
                        elementType = elementType + 1;

                end while;

-- single pilot 
            if onlineCount = 0 then
                update
                    tblGalaxy
                set ActivePilots = PilotNumber
                where GalaxyID = pGalaxyID;

            end if;

            select 'galaxy entered' as message;

        else
            select 'galaxy inaccesible' as message;

        end if;

    end if;

end;

