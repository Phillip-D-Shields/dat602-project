create
    definer = root@localhost procedure getHighScores()
begin
    select PilotName,
           TotalScore
    from tblPilot
    order by TotalScore desc
    limit 10;

end;

