create
    definer = root@localhost procedure checkGalaxy(IN pPilotID int, IN pGalaxyID int, IN pMapID int)
begin
    declare galaxyScore int default null;

    declare elementCount int default null;

    declare galaxyEmperor int default null;

    set
        galaxyScore = (select Score
                       from tblSession
                       where PilotID = pPilotID
                         and GalaxyID = pGalaxyID);

    set
        elementCount = (select count(a.VectorID)
                        from tblVectorElement as a
                                 join tblVector as t on a.VectorID = t.VectorID
                        where MapID = pMapID
                          and a.ElementID <= 4);

    set
        galaxyEmperor = (select PilotID
                         from tblSession
                         where GalaxyID = pGalaxyID
                           and Score >= 10000);

-- checks if pilot died and leaves galaxy 
    if galaxyScore < 0 then
        update
            tblSession
        set SessionActive = false
        where PilotID = pPilotID
          and GalaxyID = pGalaxyID;

        update
            tblVector
        set VectorActive = true
        where VectorID = (select VectorID
                          from tblSession
                          where PilotID = pPilotID
                            and GalaxyID = pGalaxyID);

        select 'dead - you belong to the galaxy now' as message;

    end if;


    if galaxyEmperor is not null
        or elementCount <= 0 then
        set
            galaxyEmperor = (select PilotID
                             from tblSession
                             where GalaxyID = pGalaxyID
                               and Score = (select max(Score)
                                            from tblSession
                                            where GalaxyID = pGalaxyID));

-- update pilots total score from galaxy
        update
            tblPilot as u
                join tblSession as s on u.PilotID = s.PilotID
        set u.TotalScore = u.TotalScore + s.Score
        where s.GalaxyID = pGalaxyID
          and s.Score > 0;

-- end galaxy
        delete
        from tblGalaxy
        where GalaxyID = pGalaxyID;

        select concat(
                       'this galaxy has been conquered, ',
                       (select PilotName
                        from tblPilot
                        where PilotID = galaxyEmperor),
                       ' owns this galaxy now!'
                   ) as message;

    end if;

end;

