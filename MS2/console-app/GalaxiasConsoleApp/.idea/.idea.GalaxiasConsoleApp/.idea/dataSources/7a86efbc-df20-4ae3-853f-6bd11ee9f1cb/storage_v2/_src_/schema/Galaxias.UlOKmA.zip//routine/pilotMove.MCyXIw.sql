create
    definer = root@localhost procedure pilotMove(IN pSessionID int, IN pPilotID int, IN pxPosition int, IN pyPosition int)
begin
    declare currentMapID int default null;

    declare homeVectorID int default null;

    declare startVectorID int default null;

    declare targetVectorID int default null;

    declare currentGalaxyID int default null;

    declare currentCount int default null;

    declare nextPilot int default null;

    set
        currentGalaxyID = (select GalaxyID
                           from tblSession
                           where SessionID = pSessionID);

    set
        currentMapID = (select MapID
                        from tblSession
                        where SessionID = pSessionID
                          and PilotID = pPilotID);

    set
        homeVectorID = (select VectorID
                        from tblVector
                        where MapID = currentMapID
                          and xPosition = 1
                          and yPosition = 1);

    set
        startVectorID = (select VectorID
                         from tblSession
                         where SessionID = pSessionID
                           and PilotID = pPilotID);

-- can pilot move                   
    if exists(
            select PilotNumber
            from tblSession
            where PilotNumber = (select ActivePilots
                                 from tblGalaxy
                                 where GalaxyID = currentGalaxyID)
              and SessionID = pSessionID
        ) then
        if exists(
                select *
                from tblVector as tv
                where (
                            tv.xPosition = pxPosition
                        and tv.yPosition = pyPosition
                    )
                  and tv.VectorID in (select tv2.VectorID
                                      from tblSession as s
                                               join tblVector as t on s.VectorID = t.VectorID
                                               join tblVector as tv2 on t.VectorID <> tv2.VectorID
                                      where t.MapID = currentMapID
                                        and (
                                              (tv2.xPosition = t.xPosition + 1)
                                              or (tv2.xPosition = t.xPosition - 1)
                                              or (tv2.xPosition = t.xPosition)
                                          )
                                        and (
                                              (tv2.yPosition = t.yPosition + 1)
                                              or (tv2.yPosition = t.yPosition - 1)
                                              or (tv2.yPosition = t.yPosition)
                                          )
                                        and s.SessionID = pSessionID
                                        and s.PilotID = pPilotID)
            ) then
            set
                targetVectorID = (select VectorID
                                  from tblVector
                                  where xPosition = pxPosition
                                    and yPosition = pyPosition
                                    and MapID = currentMapID);

-- vector available
            if exists(
                    select VectorID
                    from tblVector
                    where VectorID = targetVectorID
                      and VectorActive = true
                ) then
                update
                    tblSession
                set VectorID = targetVectorID
                where SessionID = pSessionID;


                update
                    tblVector
                set VectorActive = false
                where VectorID = targetVectorID
                  and VectorID <> homeVectorID;


                update
                    tblVector
                set VectorActive = true
                where VectorID = startVectorID;


                if exists(
                        select VectorID
                        from tblVectorElement
                        where VectorID = targetVectorID
                    ) then
                    update
                        tblInventory
                    set Quantity = Quantity + 1
                    where ElementID = (select ElementID
                                       from tblVectorElement
                                       where VectorID = targetVectorID);


                    update
                        tblSession
                    set Score = Score + (select e.ElementValue
                                         from tblElement as e
                                                  join tblVectorElement as t on e.ElementID = t.ElementID
                                         where t.VectorID = targetVectorID)
                    where SessionID = pSessionID;

-- removes element
                    delete
                    from tblVectorElement
                    where VectorID = targetVectorID;

                end if;

-- Update pilot turn 
                set
                    currentCount = (select count(*)
                                    from tblSession
                                    where GalaxyID = currentGalaxyID);

                set
                    nextPilot = (select PilotNumber
                                 from tblSession
                                 where SessionID = pSessionID);

-- find next pilot
                findNextPilot:
                loop
                    if nextPilot < CurrentCount then
                        set
                            nextPilot = nextPilot + 1;

                    else
                        set
                            nextPilot = 1;

                    end if;

-- check if nextPilot is online
                    if exists(
                            select PilotNumber
                            from tblSession
                            where GalaxyID = currentGalaxyID
                              and PilotNumber = nextPilot
                              and SessionActive = true
                        ) then
                        update
                            tblGalaxy
                        set ActivePilots = nextPilot
                        where GalaxyID = currentGalaxyID;

                        leave findNextPilot;

                    end if;

                end loop findNextPilot;

                select 'acceptable shift' as message;

            else
                select 'vector inaccessible' as message;

            end if;

        else
            select 'unacceptable shift' as message;

        end if;

    else
        select 'cooldown in progress, wait ...' as message;

    end if;

-- galaxy validation 
    call checkGalaxy(pPilotID, currentGalaxyID, currentMapID);

end;

