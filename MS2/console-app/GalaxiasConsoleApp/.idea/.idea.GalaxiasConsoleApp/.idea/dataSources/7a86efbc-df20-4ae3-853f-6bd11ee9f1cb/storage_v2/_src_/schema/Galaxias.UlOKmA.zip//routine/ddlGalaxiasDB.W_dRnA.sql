create
    definer = root@localhost procedure ddlGalaxiasDB()
begin

    create table tblPilot
    (
        PilotID       int         not null auto_increment primary key,
        PilotName     varchar(30) not null unique,
        PilotPassword varchar(20) not null,
        Email         varchar(50) not null,
        LoginAttempts int         not null,
        PilotLocked   bool        not null,
        PilotOnline   bool        not null,
        Administrator bool        not null,
        TotalScore    int         not null
    );

    CREATE TABLE tblGalaxy
    (
        GalaxyID     INT         NOT NULL AUTO_INCREMENT PRIMARY KEY,
        GalaxyName   VARCHAR(50) NOT NULL,
        maxPilots    INT         NOT NULL,
        ActivePilots INT,
        GalaxyStatus BOOL
    );

    CREATE TABLE tblMap
    (
        MapID    INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        GalaxyID INT NOT NULL,
        xMax     INT NOT NULL,
        yMax     INT NOT NULL,
        FOREIGN KEY (GalaxyID)
            REFERENCES tblGalaxy (GalaxyID)
            ON DELETE CASCADE
    );

    CREATE TABLE tblVector
    (
        VectorID     INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        MapID        INT NOT NULL,
        xPosition    INT NOT NULL,
        yPosition    INT NOT NULL,
        VectorActive BOOL,
        FOREIGN KEY (MapID)
            REFERENCES tblMap (MapID)
            ON DELETE CASCADE
    );

    CREATE TABLE tblElement
    (
        ElementID          INT         NOT NULL AUTO_INCREMENT PRIMARY KEY,
        ElementName        VARCHAR(30) NOT NULL,
        ElementDescription VARCHAR(50) NOT NULL,
        ElementValue       INT         NOT NULL
    );

    CREATE TABLE tblVectorElement
    (
        VectorElementID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        VectorID        INT NOT NULL,
        ElementID       INT NOT NULL,
        FOREIGN KEY (VectorID)
            REFERENCES tblVector (VectorID)
            ON DELETE CASCADE,
        FOREIGN KEY (ElementID)
            REFERENCES tblElement (ElementID)
    );

    CREATE TABLE tblSession
    (
        SessionID     INT  NOT NULL AUTO_INCREMENT PRIMARY KEY,
        PilotID       INT  NOT NULL,
        MapID         INT,
        VectorID      INT,
        GalaxyID      INT,
        PilotNumber   INT,
        Score         INT,
        SessionActive BOOL NOT NULL,
        FOREIGN KEY (PilotID)
            REFERENCES tblPilot (PilotID)
            ON DELETE CASCADE,
        FOREIGN KEY (MapID)
            REFERENCES tblMap (MapID)
            ON DELETE CASCADE,
        FOREIGN KEY (VectorID)
            REFERENCES tblVector (VectorID),
        FOREIGN KEY (GalaxyID)
            REFERENCES tblGalaxy (GalaxyID)
    );


    CREATE TABLE tblInventory
    (
        InventoryID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        PilotID     INT NOT NULL,
        SessionID   INT NOT NULL,
        ElementID   INT,
        Quantity    INT,
        FOREIGN KEY (PilotID)
            REFERENCES tblPilot (PilotID)
            ON DELETE CASCADE,
        FOREIGN KEY (SessionID)
            REFERENCES tblSession (SessionID)
            ON DELETE CASCADE,
        FOREIGN KEY (ElementID)
            REFERENCES tblElement (ElementID)
    );

end;

