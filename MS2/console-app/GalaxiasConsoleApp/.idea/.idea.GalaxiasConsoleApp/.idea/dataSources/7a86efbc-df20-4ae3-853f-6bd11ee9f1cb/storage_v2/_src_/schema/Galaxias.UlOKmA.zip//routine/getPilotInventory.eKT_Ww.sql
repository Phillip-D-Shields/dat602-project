create
    definer = root@localhost procedure getPilotInventory(IN pSessionID int)
begin
    select a.ElementDescription as Item,
           i.Quantity
    from tblInventory as i
             join tblElement as a on i.ElementID = a.ElementID
    where SessionID = pSessionID;

end;

