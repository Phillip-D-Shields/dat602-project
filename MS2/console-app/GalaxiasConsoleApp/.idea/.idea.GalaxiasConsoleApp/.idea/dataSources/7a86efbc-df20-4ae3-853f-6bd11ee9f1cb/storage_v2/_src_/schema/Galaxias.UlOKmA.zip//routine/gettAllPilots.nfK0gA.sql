create
    definer = root@localhost procedure gettAllPilots()
begin
    select PilotName
    from tblPilot;

end;

