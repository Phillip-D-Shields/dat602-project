create
    definer = root@localhost procedure pilotLogin(IN pPilotName varchar(30), IN pPilotPassword varchar(20))
begin
    declare verifyPilot int default null;

    if exists(
            select PilotID -- PilotName is existing
            from tblPilot
            where PilotName = pPilotName
        ) then
        begin
            select PilotID
            from tblPilot
            where PilotName = pPilotName
              and PilotPassword = pPilotPassword
            into verifyPilot;

            if verifyPilot is null then -- invalid password                       
                update
                    tblPilot
                set LoginAttempts = LoginAttempts + 1
                where PilotName = pPilotName;

                if (select PilotID -- failed logins less 3
                    from tblPilot
                    where PilotName = pPilotName
                      and LoginAttempts < 3) then
                    select 'bad Password' as message;

                else -- failed logins 3 or more
                    update
                        tblPilot
                    set PilotLocked = true
                    where PilotName = pPilotName;

                    select 'pilot locked - message admin' as message;

                end if;

            else
                if (select PilotID
                    from tblPilot
                    where PilotName = pPilotName
                      and PilotLocked = true) then
                    select 'pilot locked - message admin' as message;

                else
                    update
                        tblPilot
                    set LoginAttempts = 0,
                        PilotOnline   = true
                    where PilotName = pPilotName;

                    select 'success - pilot online' as message;

                end if;

            end if;

        end;

    else
        select 'bad pilot name' as message;

    end if;

end;

